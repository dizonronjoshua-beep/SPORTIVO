/* =========================================================
   SPORTIVO — TRAINEE / Profile
   Page-specific JavaScript only.
   Shared state/auth helpers remain in app.js.
========================================================= */

document.addEventListener('DOMContentLoaded', () => {
  document.documentElement.dataset.sportivoPage = 'trainee-profile';
});
